package com.iits;

import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class AppReadyLogger {

    @EventListener
    public void handleContextRefresh(ContextRefreshedEvent event) {
        System.out.println("==============================================");
        System.out.println("🚀 ALERT: DispatcherServlet context initialized!");
        System.out.println("Ready to serve: http://localhost:8080/hello");
        System.out.println("==============================================");
    }
}

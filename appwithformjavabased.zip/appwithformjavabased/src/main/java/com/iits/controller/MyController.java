package com.iits.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MyController {

	
	
	@RequestMapping("home")
	public String home() {
		return "home";
	}
	
	@RequestMapping("employee")
	public String getEmployeeForm(Model  model) {
		model.addAttribute("emp", new Employee());
		return "employee-form";
	}
	
	@RequestMapping(value = "saveEmployee",method = RequestMethod.POST)
	public String saveEmployee(@ModelAttribute("emp") Employee emp,Model model)
	{
		
		 model.addAttribute("success", "SUCCESSFULLY STORE");
		 model.addAttribute("dao", emp);
		 return "employee-success";
	}
}



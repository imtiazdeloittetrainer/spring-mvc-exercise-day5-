<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" isELIgnored="false"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
		<h2>${success}</h2>
		<hr/>
		
		<h2>Employee Data</h2>
		<table>
		<tr>
		<th>EID</th>
		<th>ENAME</th>
		<th>ESALARY</th>
		
		</tr>
		<tr>
		<td>${emp.id}</td>
		<td>${emp.name}</td>
		<td>${emp.salary}</td>
		
		</tr>
		</table>
		<hr/>
		
		<a href="employee">Click Here to Store More</a>
		
</body>
</html>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Employee Form</title>
</head>
<body>
		<form:form  action="saveEmployee" method="post" modelAttribute="emp">
			EID:<form:input path="id"/> <br/>
			ENAME:<form:input path="name"/> <br/>
			ESALARY:<form:input path="salary"/> <br/>
			<input type="submit" value="STORE">
		</form:form>	
</body>
</html>
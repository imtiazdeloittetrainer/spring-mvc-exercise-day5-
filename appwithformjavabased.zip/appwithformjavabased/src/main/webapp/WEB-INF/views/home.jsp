<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title></title>
</head>
<body>


<h1>HOME PAGE</h1>
<hr/>
  <a href="employee">Employee Form</a>


<hr/>
</body>
</html>
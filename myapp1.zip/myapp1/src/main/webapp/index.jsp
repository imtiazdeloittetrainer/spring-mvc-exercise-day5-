<html>
<body>
<h2>Hello World!</h2>
</body>
</html>

<%
response.sendRedirect(application.getContextPath() + "/deloitte/hello");
%>

package com.iits.myapp1.listener;

import org.springframework.web.servlet.FrameworkServlet;

import jakarta.servlet.ServletContextAttributeEvent;
import jakarta.servlet.ServletContextAttributeListener;

public class MyListener implements ServletContextAttributeListener {

    @Override
    public void attributeAdded(ServletContextAttributeEvent event) {
        // Spring names this attribute using the servlet's internal FrameworkServlet prefix
        if (event.getName().startsWith(FrameworkServlet.SERVLET_CONTEXT_PREFIX)) {
            String servletName = event.getName().replace(FrameworkServlet.SERVLET_CONTEXT_PREFIX, "");
            System.out.println("Traditional Listener: Servlet bound to context -> " + servletName);
        }
    }
}

package com.iits.myapp1.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HelloController {

	public HelloController() {
		System.out.println("--Hello Controller Object is created--");
	}
	
	@RequestMapping("/hello")
	@ResponseBody
	public String hello() {
		return "Welcome to Controller";
	}
}
